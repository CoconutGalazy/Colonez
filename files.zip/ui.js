/* =====================================================================
   BIOMES OF ETERNITY - ui.js
   DOM overlay: sign-in simulation, town header, inventory bar, build
   menu with locked-progression overlays, layer switcher, quest HUD,
   settler panel, alliance panel, minimap, offline report. All icons are
   inline SVG primitives (no emoji, no image files).
   ===================================================================== */
(function () {
  const $ = (s) => document.querySelector(s);
  const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; };

  const ICON = {
    wood: '<svg viewBox="0 0 16 16"><rect x="3" y="2" width="10" height="12" rx="2"/><line x1="8" y1="2" x2="8" y2="14"/></svg>',
    stone: '<svg viewBox="0 0 16 16"><polygon points="8,2 14,6 12,13 4,13 2,6"/></svg>',
    fiber: '<svg viewBox="0 0 16 16"><path d="M4 14 C4 6 8 4 8 2 M8 14 C8 8 10 6 12 3 M6 14 C6 9 3 8 2 6"/></svg>',
    ore: '<svg viewBox="0 0 16 16"><polygon points="8,1 15,8 8,15 1,8"/><circle cx="8" cy="8" r="2"/></svg>',
    crystal: '<svg viewBox="0 0 16 16"><polygon points="8,1 12,8 8,15 4,8"/></svg>',
    food: '<svg viewBox="0 0 16 16"><circle cx="8" cy="9" r="5"/><line x1="8" y1="1" x2="8" y2="4"/></svg>',
    coins: '<svg viewBox="0 0 16 16"><circle cx="8" cy="8" r="6"/><circle cx="8" cy="8" r="2.5"/></svg>',
    circle: '<svg viewBox="0 0 16 16"><circle cx="8" cy="8" r="6"/></svg>',
    diamond: '<svg viewBox="0 0 16 16"><polygon points="8,1 15,8 8,15 1,8"/></svg>',
    square: '<svg viewBox="0 0 16 16"><rect x="2" y="2" width="12" height="12"/></svg>',
    lock: '<svg viewBox="0 0 16 16"><rect x="3" y="7" width="10" height="8" rx="1"/><path d="M5 7 V5 a3 3 0 0 1 6 0 V7"/></svg>',
    sky: '<svg viewBox="0 0 16 16"><path d="M2 10 h12 M4 6 h8 M6 3 h4"/></svg>',
    surface: '<svg viewBox="0 0 16 16"><path d="M1 12 L5 6 L8 9 L11 4 L15 12 Z"/></svg>',
    depths: '<svg viewBox="0 0 16 16"><path d="M2 3 h12 M4 3 v9 h8 V3"/><polygon points="8,7 10,10 6,10"/></svg>',
    mail: '<svg viewBox="0 0 16 16"><rect x="1" y="3" width="14" height="10" rx="1"/><path d="M1 4 L8 9 L15 4"/></svg>',
  };
  const RES = ['wood', 'stone', 'fiber', 'ore', 'crystal', 'food'];

  /* ---------- auth simulation ---------- */
  function initAuth() {
    const modal = $('#auth');
    $('#auth-gmail').addEventListener('click', () => {
      const email = ($('#auth-email').value || '').trim();
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) { $('#auth-err').textContent = 'Enter a valid email address to continue.'; return; }
      const name = email.split('@')[0].replace(/[._-]+/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
      const user = { email, name, provider: 'gmail-sim', signedIn: Date.now() };
      $('#auth-gmail').textContent = 'Signing in...';
      setTimeout(() => { modal.classList.add('hidden'); Game.startGame(user); }, 500);
    });
    $('#auth-guest').addEventListener('click', () => { modal.classList.add('hidden'); Game.startGame({ email: '', name: 'Mayor', provider: 'guest' }); });
    $('#auth-email').addEventListener('keydown', e => { if (e.key === 'Enter') $('#auth-gmail').click(); });
  }

  /* ---------- HUD ---------- */
  function renderTown() {
    const s = Game.state;
    $('#town-name').textContent = s.townName;
    $('#town-user').textContent = s.user && s.user.name ? s.user.name : 'Mayor';
    renderExp();
  }
  function renderExp() {
    const s = Game.state, tier = Game.seasonTier();
    const next = Game.SEASON_PASS[tier] ? Game.SEASON_PASS[tier].exp : Game.SEASON_PASS[tier - 1].exp;
    const prev = Game.SEASON_PASS[tier - 1].exp;
    const f = next > prev ? (s.exp - prev) / (next - prev) : 1;
    $('#lvl').textContent = 'LV ' + s.level;
    $('#tier').textContent = 'TIER ' + tier;
    $('#exp-fill').style.width = Math.round(f * 100) + '%';
    $('#exp-text').textContent = s.exp + ' / ' + next + ' EXP';
    $('#def').textContent = 'DEF x' + Game.defenseMultiplier().toFixed(2);
    $('#coins').textContent = s.coins;
  }
  function renderInv() {
    const bar = $('#inv'); bar.innerHTML = '';
    for (const r of RES) bar.appendChild(el('div', 'inv-slot', ICON[r] + '<span class="n">' + (Game.state.inv[r] || 0) + '</span><span class="l">' + r + '</span>'));
    $('#coins').textContent = Game.state.coins;
  }
  function renderHp() {
    const p = Game.player; $('#hp-fill').style.width = Math.round(p.hp / p.maxHp * 100) + '%';
    $('#hp-text').textContent = Math.round(p.hp) + ' / ' + p.maxHp;
  }
  function renderLog(log) {
    const box = $('#log'); box.innerHTML = '';
    for (const l of log) box.appendChild(el('div', 'log-' + l.kind, l.msg));
  }
  function renderQuest() {
    const q = Game.QUESTS[Game.state.questIndex];
    $('#quest-idx').textContent = q ? 'QUEST ' + (Game.state.questIndex + 1) + ' / ' + Game.QUESTS.length : 'ALL QUESTS COMPLETE';
    $('#quest-title').textContent = q ? q.title : 'The eternal biomes await';
    $('#quest-desc').textContent = q ? q.desc : 'Expand, ally, and sail. Season tiers keep unlocking.';
    $('#quest-exp').textContent = q ? '+' + q.exp + ' EXP' : '';
  }

  /* ---------- build menu with locked overlays ---------- */
  function renderBuild() {
    const grid = $('#build-grid'); grid.innerHTML = '';
    const s = Game.state;
    for (const type in Game.BUILD_RECIPES) {
      const R = Game.BUILD_RECIPES[type];
      const unlocked = Game.recipeUnlocked(type);
      const afford = Object.keys(R.cost).every(k => (k === 'coins' ? s.coins : s.inv[k] || 0) >= R.cost[k]);
      const card = el('button', 'build-card' + (unlocked ? '' : ' locked') + (afford ? '' : ' poor') + (Game.buildMode === type ? ' active' : ''));
      card.innerHTML = '<div class="bc-shape">' + ICON.square + '</div><div class="bc-name">' + R.name + '</div><div class="bc-cost">' +
        Object.keys(R.cost).map(k => '<span' + ((k === 'coins' ? s.coins : s.inv[k] || 0) < R.cost[k] ? ' class="short"' : '') + '>' + R.cost[k] + ' ' + k + '</span>').join(' ') +
        '</div><div class="bc-desc">' + R.desc + '</div>' +
        (unlocked ? '' : '<div class="bc-lock">' + ICON.lock + '<span>Season tier ' + (R.tier + 1) + '</span></div>');
      card.disabled = !unlocked;
      card.addEventListener('click', () => { Game.setBuildMode(Game.buildMode === type ? null : type); });
      grid.appendChild(card);
    }
  }
  function renderPass() {
    const box = $('#pass'); box.innerHTML = '';
    const tier = Game.seasonTier();
    for (const t of Game.SEASON_PASS) box.appendChild(el('div', 'pass-tier' + (t.tier <= tier ? ' done' : ''), '<b>T' + t.tier + '</b><span>' + t.reward + '</span><i>' + t.exp + ' EXP, DEF x' + t.defense + '</i>'));
  }

  /* ---------- settler panel ---------- */
  function renderSelect(n) {
    const box = $('#settler');
    if (!n) { box.classList.add('hidden'); return; }
    box.classList.remove('hidden');
    $('#settler-name').innerHTML = ICON[n.shape] + ' ' + n.name;
    $('#settler-role').textContent = 'Currently: ' + n.role;
    box.querySelectorAll('[data-role]').forEach(b => { b.classList.toggle('active', b.dataset.role === n.role); });
  }
  $('#settler').addEventListener('click', e => {
    const b = e.target.closest('[data-role]'); if (!b || !Game.selected) return;
    const nn = Game.setNpcRole(Game.selected, b.dataset.role); renderSelect(nn);
  });

  /* ---------- alliances ---------- */
  function renderAlliance() {
    const list = $('#ally-list'); list.innerHTML = '';
    for (const r of Game.state.rivals) {
      const row = el('div', 'ally-row');
      const hall = Game.townHall();
      const dist = hall ? Math.round(Math.hypot(hall.x - r.x, hall.z - r.z)) : Math.round(Math.hypot(Game.player.x - r.x, Game.player.z - r.z));
      const isFriend = Game.state.friends.includes(r.name);
      row.innerHTML = '<div class="ally-head">' + ICON.diamond + '<b>' + r.name + '</b><span class="rel rel-' + r.relation + '">' + r.relation + (r.treaty ? ' + treaty' : '') + '</span></div>' +
        '<div class="ally-meta">' + dist + ' units away, power ' + r.power + ', ' + r.houses + ' houses' + (r.pending > 0 ? ', considering your request' : '') + '</div>';
      const acts = el('div', 'ally-acts');
      const f = el('button', 'btn small', isFriend ? 'Friend' : 'Add friend'); f.disabled = isFriend;
      f.addEventListener('click', () => { Game.state.friends.push(r.name); Game.notify(r.name + ' added as a friend. Alliances come easier.'); renderAlliance(); });
      const a = el('button', 'btn small', r.relation === 'ally' ? 'Allied' : 'Request alliance'); a.disabled = r.relation === 'ally' || r.pending > 0;
      a.addEventListener('click', () => { Game.requestAlliance(r); renderAlliance(); });
      const t = el('button', 'btn small', r.treaty ? 'Treaty active' : 'Defense treaty (20c)'); t.disabled = r.relation !== 'ally' || r.treaty;
      t.addEventListener('click', () => { Game.proposeTreaty(r); renderAlliance(); });
      acts.append(f, a, t); row.appendChild(acts); list.appendChild(row);
    }
    $('#ally-buffer').textContent = 'Territory buffer: ' + Game.TERRITORY_RADIUS + ' units. Neighbours cannot claim land inside your radius without an alliance; allies may share borders.';
  }

  /* ---------- minimap: samples the generator directly (no chunk needed) ---------- */
  const mm = $('#minimap'), mctx = mm.getContext('2d');
  function renderMinimap() {
    const p = Game.player, N = 48, cell = mm.width / N, span = 96;
    const img = mctx.createImageData(mm.width, mm.height);
    for (let i = 0; i < N; i++) for (let j = 0; j < N; j++) {
      const wx = Math.floor(p.x + (i - N / 2) * span / N), wz = Math.floor(p.z + (j - N / 2) * span / N);
      const t = Game.world.gen.tile(wx, wz, p.layer);
      const col = t.exists ? BIOMES[t.biome].ground : 0x0a0a0c;
      const r = (col >> 16) & 255, g = (col >> 8) & 255, b = col & 255;
      for (let y = 0; y < cell; y++) for (let x = 0; x < cell; x++) {
        const k = ((Math.floor(j * cell) + y) * mm.width + Math.floor(i * cell) + x) * 4;
        img.data[k] = r; img.data[k + 1] = g; img.data[k + 2] = b; img.data[k + 3] = 255;
      }
    }
    mctx.putImageData(img, 0, 0);
    const toPx = (x, z) => [(x - p.x) / span * mm.width + mm.width / 2, (z - p.z) / span * mm.height + mm.height / 2];
    const hall = Game.townHall();
    if (hall && p.layer === 'surface') { const [hx, hz] = toPx(hall.x, hall.z); mctx.strokeStyle = 'rgba(232,196,120,0.7)'; mctx.beginPath(); mctx.arc(hx, hz, Game.TERRITORY_RADIUS / span * mm.width, 0, Math.PI * 2); mctx.stroke(); }
    mctx.fillStyle = '#e8c478';
    for (const b of Game.buildings) if (b.layer === p.layer) { const [x, z] = toPx(b.x, b.z); mctx.fillRect(x - 1.5, z - 1.5, 3, 3); }
    mctx.fillStyle = '#c0392b';
    for (const e of Game.enemies) if (e.layer === p.layer) { const [x, z] = toPx(e.x, e.z); mctx.fillRect(x - 1.5, z - 1.5, 3, 3); }
    if (p.layer === 'surface') { mctx.fillStyle = '#9fc4ff'; for (const r of Game.state.rivals) { const [x, z] = toPx(r.x, r.z); mctx.fillRect(x - 2, z - 2, 4, 4); } }
    mctx.fillStyle = '#fff'; mctx.beginPath(); mctx.arc(mm.width / 2, mm.height / 2, 2.5, 0, Math.PI * 2); mctx.fill();
    const t = Game.world.gen.tile(Math.floor(p.x), Math.floor(p.z), p.layer);
    $('#biome').textContent = (t.exists ? BIOMES[t.biome].name : 'Open air') + '  ' + Math.round(p.x) + ', ' + Math.round(p.z);
  }

  /* ---------- offline report ---------- */
  function renderOffline(r) {
    const box = $('#offline'); box.classList.remove('hidden');
    $('#offline-body').innerHTML = 'You were away <b>' + r.hours + ' h</b>. Base armor multiplier <b>x' + r.armor + '</b> applied. ' +
      '<b>' + r.guards + '</b> guard' + (r.guards === 1 ? '' : 's') + ' held the perimeter through <b>' + r.raids + '</b> raid' + (r.raids === 1 ? '' : 's') + ': ' +
      '<b>' + r.repelled + '</b> repelled, <b>' + r.lost + '</b> broke through.' + (r.food ? ' Farmers stored <b>' + r.food + '</b> food.' : '');
  }

  /* ---------- wiring ---------- */
  function initHud() {
    document.querySelectorAll('[data-layer]').forEach(b => b.addEventListener('click', () => Game.switchLayer(b.dataset.layer)));
    $('#btn-build').addEventListener('click', () => togglePanel('build'));
    $('#btn-ally').addEventListener('click', () => togglePanel('ally'));
    $('#btn-pass').addEventListener('click', () => togglePanel('pass-panel'));
    document.querySelectorAll('.close').forEach(c => c.addEventListener('click', () => c.closest('.panel').classList.add('hidden')));
    $('#town-name').addEventListener('click', () => { $('#rename').classList.remove('hidden'); $('#rename-input').value = Game.state.townName; $('#rename-input').focus(); });
    $('#rename-ok').addEventListener('click', () => { const r = Game.renameTown($('#rename-input').value); $('#rename-err').textContent = r.ok ? '' : r.why; if (r.ok) $('#rename').classList.add('hidden'); });
    $('#rename-input').addEventListener('keydown', e => { if (e.key === 'Enter') $('#rename-ok').click(); });
    addEventListener('keydown', e => {
      if (e.target.tagName === 'INPUT') return;
      const k = e.key.toLowerCase();
      if (k === 'b') togglePanel('build'); if (k === 'f') togglePanel('ally'); if (k === 'p') togglePanel('pass-panel');
      if (k === '1') Game.switchLayer('sky'); if (k === '2') Game.switchLayer('surface'); if (k === '3') Game.switchLayer('depths');
    });
  }
  function togglePanel(id) { const p = $('#' + id); p.classList.toggle('hidden'); if (!p.classList.contains('hidden')) { if (id === 'build') renderBuild(); if (id === 'ally') renderAlliance(); if (id === 'pass-panel') renderPass(); } }

  Game.on('ready', () => {
    $('#hud').classList.remove('hidden');
    renderTown(); renderInv(); renderHp(); renderQuest(); renderMinimap(); renderLayer(Game.player.layer);
  });
  Game.on('inv', () => { renderInv(); renderExp(); if (!$('#build').classList.contains('hidden')) renderBuild(); });
  Game.on('exp', renderExp);
  Game.on('hp', renderHp);
  Game.on('log', renderLog);
  Game.on('quest', renderQuest);
  Game.on('town', renderTown);
  Game.on('select', renderSelect);
  Game.on('rivals', () => { if (!$('#ally').classList.contains('hidden')) renderAlliance(); });
  Game.on('openAlliance', () => { $('#ally').classList.remove('hidden'); renderAlliance(); });
  Game.on('offline', renderOffline);
  Game.on('buildMode', t => { $('#build-hint').textContent = t ? 'Placing ' + Game.BUILD_RECIPES[t].name + '. Click to place, Shift-click to place several, right-click or Esc to cancel.' : ''; if (!$('#build').classList.contains('hidden')) renderBuild(); });
  Game.on('layer', renderLayer);
  Game.on('tick', () => { renderMinimap(); renderHp(); if (Game.ghostStatus && Game.buildMode) $('#build-hint').textContent = Game.ghostStatus.ok ? 'Placing ' + Game.BUILD_RECIPES[Game.buildMode].name + '. Click to place.' : Game.ghostStatus.why; });
  function renderLayer(layer) { document.querySelectorAll('[data-layer]').forEach(b => b.classList.toggle('active', b.dataset.layer === layer)); }

  document.addEventListener('DOMContentLoaded', () => { initAuth(); initHud(); for (const k in ICON) document.querySelectorAll('[data-icon="' + k + '"]').forEach(e => e.innerHTML = ICON[k]); });
})();
